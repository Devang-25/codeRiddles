

  vector<float> YP;
int MONTH[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; 

vector<string> tokenize(string str, char delim = ',') {
  vector<string> T;
  string token;
  istringstream S(str);
  while(getline(S, token, delim)) T.push_back(token);
  return T;
}


// 0: PCP (100 .. 3200)
// 1: TMP (-200 .. 10000)
// 2: PDSI (-1000 .. 1000)
// 3: ZNDX (-1000 .. 1000)
// 4: CCD  (-600 .. 2000)
// 5: HDD  (-1000 .. 1000)
// 6: SP01  (-300 .. 300)
// 7: SP02  (-300 .. 300)
// 8: SP03  (-300 .. 300)
// 9: SP06  (-300 .. 300)
// 10: SP09 (-300 .. 300)
// 11: SP12 (-300 .. 300)
// 12: SP24 (-300 .. 300)
map<int, map<int, vector<int> > > NOAA;
map<int, map<int, vector<int> > > LOC_NOAA;
void init_NOAA(vector<string> V) {
  for(int i = 0; i < V.size(); i++) {
    vector<string> T = tokenize(V[i]);
    if(T.size() != 18) continue;
    int loc = 100*atoi(T[0].c_str()) + atoi(T[1].c_str());
    int date = atoi(T[2].c_str());
    
    vector<int> R;
    for(int i = 3; i < 18; i++) R.push_back((int) (atof(T[i].c_str())*100.));
    R[6] /= 100;
    R[7] /= 100;
    NOAA[loc][date] = R;
  }
}


map<int, map<int, vector<int> > > DMonitor;
map<int, map<int, vector<int> > > LOC_DMonitor;
void init_DMonitor(vector<string> V) {
  for(int i = 0; i < V.size(); i++) {
    vector<string> T = tokenize(V[i]);
    if(T.size() != 8) continue;
    int fips = atoi(T[1].c_str());
    int date = atoi(T[0].c_str());
    vector<int> R;
    for(int i = 2; i < 8; i++) R.push_back((int) (atof(T[i].c_str())*100.));
    DMonitor[fips][date] = R;
  }
}

// 0: X (27 .. 49)
// 1: Y (-101 .. -75)
// 2: maturity (3 .. 12)
// 3: submaturity (1 .. 3)
// 4: maturityband (1 .. 5)
map<int, vector<int> > LOC;
void init_location(vector<string> V) {
  map<int, int> NB;

  for(int i = 0; i < V.size(); i++) {
    vector<string> T = tokenize(V[i]);
    if(T.size() != 10) continue;
    int loc = atoi(T[0].c_str());
    NB[loc]++;

    vector<int> R;
    R.push_back(int(atof(T[1].c_str()) * 10)); // X
    R.push_back(int(atof(T[2].c_str()) * 10)); // Y
    R.push_back(3 + atoi(T[4].c_str()));       // Maturity
    if(T[5] == "Early") R.push_back(1); // Sub maturity
    else if(T[5] == "Mid") R.push_back(2);
    else if (T[5] == "Late") R.push_back(3);
    else R.push_back(0);   
    R.push_back(atoi(T[6].c_str())); // Maturity Band


    R.push_back(atoi(T[7].c_str())); // Maturity Band
    R.push_back(atoi(T[8].c_str())); // Maturity Band
    R.push_back(atoi(T[9].c_str())/1000); // Maturity Band


    if(LOC[loc].size() == 0) LOC[loc] = R;
    else for(int i = 0; i < LOC[loc].size(); i++) LOC[loc][i] += R[i];

    int noaa_id = atoi(T[7].c_str()) * 100 + atoi(T[8].c_str());
    for(map<int, vector<int> >::iterator it = NOAA[noaa_id].begin(); it != NOAA[noaa_id].end(); ++it) {
      if(LOC_NOAA[loc][it->first].size() == 0) LOC_NOAA[loc][it->first] = it->second;
      else for(int i = 0; i < LOC_NOAA[loc][it->first].size(); i++)
        LOC_NOAA[loc][it->first][i] += (it->second)[i];
    }
    int fips = atoi(T[9].c_str());
    for(map<int, vector<int> >::iterator it = DMonitor[fips].begin(); it != DMonitor[fips].end(); ++it) {
      if(LOC_DMonitor[loc][it->first].size() == 0) LOC_DMonitor[loc][it->first] = it->second;
      else for(int i = 0; i < LOC_DMonitor[loc][it->first].size(); i++)
        LOC_DMonitor[loc][it->first][i] += (it->second)[i];
    }

    loc = 1000 * (loc/1000);
    NB[loc]++;

    if(LOC[loc].size() == 0) LOC[loc] = R;
    else for(int i = 0; i < LOC[loc].size(); i++) LOC[loc][i] += R[i];

    for(map<int, vector<int> >::iterator it = NOAA[noaa_id].begin(); it != NOAA[noaa_id].end(); ++it) {
      if(LOC_NOAA[loc][it->first].size() == 0) LOC_NOAA[loc][it->first] = it->second;
      else for(int i = 0; i < LOC_NOAA[loc][it->first].size(); i++)
        LOC_NOAA[loc][it->first][i] += (it->second)[i];
    }
    for(map<int, vector<int> >::iterator it = DMonitor[fips].begin(); it != DMonitor[fips].end(); ++it) {
      if(LOC_DMonitor[loc][it->first].size() == 0) LOC_DMonitor[loc][it->first] = it->second;
      else for(int i = 0; i < LOC_DMonitor[loc][it->first].size(); i++)
        LOC_DMonitor[loc][it->first][i] += (it->second)[i];
    }
  }

  for(map<int,int>::iterator it = NB.begin(); it != NB.end(); ++it) {
    int loc = it->first;
    int nb = it->second;
    for(int i = 0; i < LOC[loc].size(); i++) 
      LOC[loc][i] = (int) (0.5 + double(LOC[loc][i]) / double(nb));
    for(map<int, vector<int> >::iterator it = LOC_NOAA[loc].begin(); it != LOC_NOAA[loc].end(); ++it)
      for(int i = 0; i < (it->second).size(); i++) (it->second)[i] = (int) (0.5 + double((it->second)[i]) / double(nb));
    for(map<int, vector<int> >::iterator it = LOC_DMonitor[loc].begin(); it != LOC_DMonitor[loc].end(); ++it)
      for(int i = 0; i < (it->second).size(); i++) (it->second)[i] = (int) (0.5 + double((it->second)[i]) / double(nb));

  }
}



class Key {
  public: 
  int index;
  int ExperimentID;
  int LOCCD;
  int REPNO;
  int MaterialId;
  int HERB;
  int RM;
  int SRM;
  int PlantDate;
  Key(string ExperimentID, string LOCCD, string REPNO, string MaterialID, string HERB, string RM, string PlantDate) : index(-1) {
    this->ExperimentID = atoi(ExperimentID.c_str());
    this->LOCCD = atoi(LOCCD.c_str());
    this->REPNO = atoi(REPNO.c_str());
    this->MaterialId = atoi(MaterialID.c_str());
    if(HERB == "conv") this->HERB = 1;
    else if(HERB == "RR1") this->HERB = 2;
    else if(HERB == "RR2Y") this->HERB = 3;
    else this->HERB = 0;

    for(int i = 0; i < RM.length(); i++) if(RM[i] == '.') {RM.erase(i,1); break;}
    if(RM.find("000") == 0)     {this->RM = 1; RM.erase(0, 3);}
    else if(RM.find("00") == 0) {this->RM = 2; RM.erase(0, 2);}
    else if(RM.find("0") == 0)  {this->RM = 3; RM.erase(0, 1);}
    else if(RM.find("10") == 0) {this->RM = 13; RM.erase(0, 2);}
    else if(RM.find("1") == 0)  {this->RM = 4; RM.erase(0, 1);}
    else if(RM.find("2") == 0)  {this->RM = 5; RM.erase(0, 1);}
    else if(RM.find("3") == 0)  {this->RM = 6; RM.erase(0, 1);}
    else if(RM.find("4") == 0)  {this->RM = 7; RM.erase(0, 1);}
    else if(RM.find("5") == 0)  {this->RM = 8; RM.erase(0, 1);}
    else if(RM.find("6") == 0)  {this->RM = 9; RM.erase(0, 1);}
    else if(RM.find("7") == 0)  {this->RM = 10; RM.erase(0, 1);}
    else if(RM.find("8") == 0)  {this->RM = 11; RM.erase(0, 1);}
    else if(RM.find("9") == 0)  {this->RM = 12; RM.erase(0, 1);}
    else {this->RM = 0; RM = "";}

    if(RM.length() > 0) this->SRM = (RM[0] - '0');
    else this->SRM = 0;

    this->PlantDate = 0;
    for(int i = 0; i < PlantDate.length(); i++) 
      if(PlantDate[i] >= '0' && PlantDate[i] <= '9') 
        this->PlantDate = this->PlantDate*10 + PlantDate[i] - '0';

  }
};


vector<Key> TRAINKEY;
vector<float> YIELD;

Key parse_training(string line, float &yield) {
  istringstream S(line);
  vector<string> T;
  string token;
  while(getline(S, token, ',')) T.push_back(token);
  while(T.size() < 9) T.push_back("");

  yield = atof(T[5].c_str());
  return Key(T[0], T[1], T[2], T[3], T[4], T[7], T[8]);
}

struct Extractor {
  int* BUFFER;
  int pos;

  virtual int _extract(const Key &K) = 0;

  unsigned int extract(const Key &K) {
    if(BUFFER && K.index != -1) return BUFFER[K.index];
    else return _extract(K);
  };

  Extractor() : BUFFER(0), pos(-1) {}
  
  virtual string _print()  = 0;
  string print() {
    if(pos != -1) {
      stringstream S;
      S << "EXTR[" << pos << "]";
      return S.str();
    }
    else return _print();
  }

  virtual ~Extractor() {}
  void bufferize() {
    if(BUFFER) return;
    BUFFER = new int[TRAINKEY.size()];
    for(int i = 0; i < TRAINKEY.size(); i++) BUFFER[i] = _extract(TRAINKEY[i]);
  }
};


class Bucket {
  public:
  int M;

  int* N;
  float* S;
  float* P;
 float alpha;
  Extractor *E;

  void compute_pred() {
    for(int i = 0; i < M; i++) P[i] = alpha * S[i] / float(N[i]+1);
  }

  void clear() {
    delete[] N; N = 0;
    delete[] S; S = 0;
    delete[] P; P = 0;
  }
  
  Bucket(Extractor *E, int M, float alpha = 1.) : E(E), M(M), N(0), S(0), P(0), alpha(alpha) {}

  Bucket(const Bucket& B) {
    M = B.M;
    alpha = B.alpha;
    if(B.N) {N = new int[M]; memcpy(N, B.N, M*sizeof(int));} else N = 0;
    if(B.S) {S = new float[M]; memcpy(S, B.S, M*sizeof(float));} else S = 0;
    if(B.P) {P = new float[M]; memcpy(P, B.P, M*sizeof(float));} else P = 0;
  }


  inline unsigned int get_value(const Key& K) {
    return (E->extract(K) % M);
  }

  void init() {
    delete[] N; N = new int[M];   memset(N, 0, M*sizeof(int));
    delete[] S; S = new float[M]; memset(S, 0, M*sizeof(float));
    delete[] P; P = new float[M]; memset(P, 0, M*sizeof(float));
  }

  void train(const Key &K, float obs) {
    unsigned int k = get_value(K);
    N[k]++;
    S[k] += obs;
  }

  float predict(const Key &K) {
    return P[get_value(K)];
  }

  string print() {
    ostringstream S;
    S << "Bucket(new " << E->print() << "," << M << "," << alpha << ")";
    return S.str();
  }

  ~Bucket() {clear();}



};


struct _EMPTY : public Extractor {
  int _extract(const Key &K) {return 0;}
  string _print() {return "_EMPTY()";}
};

struct _REPNO : public Extractor {
  int _extract(const Key &K) {return K.REPNO;}
  string _print() {return "_REPNO()";}
};

struct _ExperimentID : public Extractor {
  int _extract(const Key &K) {return K.ExperimentID;}
  string _print() {return "_ExperimentID()";}
};

struct _ExpRep : public Extractor {
  int _extract(const Key &K) {return K.ExperimentID*8 + K.REPNO;}
  string _print() {return "_ExpRep()";}
};


struct _LOCID : public Extractor {
  int _extract(const Key &K) {return K.LOCCD;}
  string _print() {return "_LOCID()";}
};

struct _LOCID2 : public Extractor {
  int _extract(const Key &K) {return K.LOCCD/1000;}
  string _print() {return "_LOCID2()";}
};

struct _MaterialId : public Extractor {
  int _extract(const Key &K) {return K.MaterialId;}
  string _print() {return "_MaterialId()";}
};

struct _HERB : public Extractor {
  int _extract(const Key &K) {return K.HERB;}
  string _print() {return "_HERB()";}
};

struct _RM : public Extractor {
  int _extract(const Key &K) {return K.RM;}
  string _print() {return "_RM()";}
};

struct _SRM : public Extractor {
  int _extract(const Key &K) {return K.SRM;}
  string _print() {return "_SRM()";}
};

struct _YEAR : public Extractor {
  int _extract(const Key &K) {return K.PlantDate / 10000;}
  string _print() {return "_YEAR()";}
};

struct _DAY : public Extractor {
  int _extract(const Key &K) {return K.PlantDate % 100;}
  string _print() {return "_DAY()";}
};

struct _MONTH : public Extractor {
  int _extract(const Key &K) {return (K.PlantDate / 100) % 100;}
  string _print() {return "_MONTH()";}
};

struct _DAYOFYEAR : public Extractor {
  int _extract(const Key &K) {
    int dayOfYear = _DAY().extract(K);
    int month = _MONTH().extract(K);
    for(int i = 0; i < month - 1; i++) dayOfYear += MONTH[i];
    return dayOfYear;
  }
  string _print() {return "_DAYOFYEAR()";}
};

struct _CLIMATE : public Extractor {
  const int source;
  const int pos;
  const int length;
  const int offset;
  const int relative;
  const int div;
  const map<int, map< int, vector<int> > > &MAP;

  _CLIMATE(int source, int pos, int length, int offset, int relative = 1, int div = 1) 
    : Extractor(), source(source), pos(pos), length(length), offset(offset), relative(relative), div(div), MAP((source == 0)?LOC_NOAA:LOC_DMonitor) {}

  int _extract(const Key &K) {
    int year = _YEAR().extract(K);
    int loc = _LOCID().extract(K);
    int date;

    if(source == 0) 
      date = year*100 + _MONTH().extract(K);
    else 
      date = K.PlantDate;
   
    if(!relative) {
      if(source == 0) date = year*100 + 1;
      else date = year*10000 + 7;
    }

    if(MAP.find(loc) == MAP.end()) loc = 1000*(loc/1000);
    if(MAP.find(loc) == MAP.end()) return -9999;

    const map<int, vector<int> > &M = MAP.find(loc)->second;
    map<int, vector<int> >::const_iterator it = M.lower_bound(date);
    if(it == M.end()) {
      cerr << "bubu1 " << loc << " " << year << " " << source << "," << pos << "," << length << "," << offset << "," << relative << "," << div << " # " << (it->second).size() << endl;
      return -9999;
    }

    if(offset < 0) for(int k = 0; k < -offset; k++) --it;
    else if(offset > 0) for(int k = 0; k < offset && it != M.end(); k++) ++it;


    int nb = 0, sum = 0;
    for(; nb < length && it != M.end(); ++it) {
      if((it->second).size() <= pos) {
        cerr << "bubu2 " << loc << " " << year << " "  << source << "," << pos << "," << length << "," << offset << "," << relative << "," << div << " # " << (it->second).size() <<  " " << nb << endl;
        break;

      }
      sum += (it->second)[pos];
      nb++;
    }
    if(nb > 0) return (sum / nb) / div;
    else return 0;
  }

  string _print() {
    ostringstream S;
    S << "_CLIMATE(" << source << "," << pos << "," << length << "," << offset << "," << relative << "," << div << ")";
    return S.str();
  }
};


struct _LOCVAR : public Extractor {
  int index;
  _LOCVAR(int index) : Extractor(), index(index) {} 

  int _extract(const Key &K) {
    int loc = _LOCID().extract(K);
    if(LOC.find(loc) == LOC.end()) loc = 1000*(loc/1000);
    map<int, vector<int> >::iterator it = LOC.find(loc);
    if(it == LOC.end()) return 0;
    else return (it->second)[index];
  }

  string _print() {
    ostringstream S;
    S << "_LOCVAR(" << index << ")";
    return S.str();
  }
};



struct _PAIR : public Extractor {
  Extractor* E1;
  Extractor* E2;
  int A1, A2, d1, d2;

  _PAIR(Extractor *E1, Extractor *E2, int A1, int A2, int d1 = 1, int d2 = 1) : Extractor(), E1(E1), E2(E2), A1(A1), A2(A2), d1(d1), d2(d2) {}

  int _extract(const Key &K) {
    int v1 = E1->extract(K);
    int v2 = E2->extract(K);
    return A1*(v1/d1) + A2*(v2/d2);
  }
  string _print() {
    ostringstream S;
    S << "_PAIR(new " << E1->print() << ",new " << E2->print() << "," << A1 << "," << A2 << "," << d1 << "," << d2 << ")";
    return S.str();
  }


};

