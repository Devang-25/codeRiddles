#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <map>
#include <cstring>

using namespace std;


#include "Common.cpp"


vector<string> readfile(const char* filename, int skip = 0) {
  vector<string> R;
  ifstream F;
  F.open(filename);
  string L;
  for(int i = 0; i < skip; i++) getline(F, L);
  while(!F.eof()) {
    getline(F, L);
    if(F.fail()) break;
    R.push_back(L);
  }
  return R;
}

int fold;

void init() {
  vector<string> V = readfile("DroughtNOAA.csv", 1);
  init_NOAA(V);
  cerr << "init NOAA OK" << endl;

  V = readfile("DroughtMonitor.csv", 1);
  init_DMonitor(V);
  cerr << "init DroughtMonitor OK" << endl;

  V = readfile("Locations.csv", 0);
  init_location(V);
  cerr << "init Locations OK" << endl;

  V = readfile("ValidExperiments.csv", 0);
  map<int, int> FOLD;
  for(int i = 0; i < V.size(); i++) FOLD[atoi(V[i].c_str())] = 1 + i%3;

  
  V = readfile("DataTraining.csv", 0);
  for(int i = 0; i < V.size(); i++) {
    float Y;    
    Key K = parse_training(V[i], Y);    

    if(FOLD[K.ExperimentID] != fold) {
      K.index = TRAINKEY.size();
      TRAINKEY.push_back(K);
      YIELD.push_back(Y);
    }
  }
}


#include <pthread.h>
int NB_THREAD = 16;
pthread_t threads[64];

vector<Bucket*> Cand;
vector<double> MSE(Cand.size());
//vector<double> MSE_VAL(Cand.size());

void* thread_train(void* arg) {
  int k = *(int*)(arg);

  for(int j = k; j < Cand.size(); j += NB_THREAD) 
    Cand[j]->init();

  for(int i = 0; i < TRAINKEY.size(); i++)
    for(int j = k; j < Cand.size(); j += NB_THREAD) {
      float p = YIELD[i] - YP[i];
      if(p > 15) p = 15; 
      if(p < -15) p = -15;
      Cand[j]->train(TRAINKEY[i], p);
    }

  return 0;
}

void* thread_mse(void* arg) {
  int k = *(int*)(arg);

  for(int j = k; j < Cand.size(); j += NB_THREAD) 
    Cand[j]->compute_pred();

  for(int i = 0; i < TRAINKEY.size(); i++)
    for(int j = k; j < Cand.size(); j += NB_THREAD) {
      float err = abs(YP[i] + Cand[j]->predict(TRAINKEY[i]) - YIELD[i]);
      if(err > 15) MSE[j] += 30*err - 15*15;
      else MSE[j] += err*err;
      /*


         err *= err;
         MSE[j] += err;
         if(err > 25*25) err = 25*25;
         MSE_VAL[j] += err;*/
    }
  return 0;
}



  vector<Extractor*> V2;
  vector<Extractor*> V1;

void* thread_bufferize(void* arg) {
  int k = *(int*)(arg);
  for(int j = k; j < V1.size(); j += NB_THREAD) V1[j]->bufferize();
  return 0;
}


int main(int argc, char** argv) {
  fold = -1;
  if(argc > 1) fold = atoi(argv[1]);

  cerr << "fold: " << fold << endl;

  init();
  cerr << "Train size " << TRAINKEY.size() << " " << YIELD.size() << endl;

  cerr << "init OK" << endl;

  V1.push_back(new _ExperimentID());
  V1.push_back(new _ExpRep());
  V1.push_back(new _LOCID());
  V1.push_back(new _MaterialId());
  V1.push_back(new _LOCVAR(0));
  V1.push_back(new _LOCVAR(1));


  V1.push_back(new _REPNO());
  V1.push_back(new _HERB());
  V1.push_back(new _RM());
  V1.push_back(new _SRM());
  V1.push_back(new _YEAR());
  V1.push_back(new _MONTH());
  V1.push_back(new _DAY());
  V1.push_back(new _DAYOFYEAR());
  V1.push_back(new _PAIR(new _DAYOFYEAR(), new _DAYOFYEAR(), 1, 0, 5, 5));
  V1.push_back(new _PAIR(new _DAY(), new _DAY(), 1, 0, 3, 3));
  for(int i = 2; i < 5; i++) V1.push_back(new _LOCVAR(i));


/*
  for(int pos = 0; pos < 6; pos++)
    for(int length = 1; length < 7; length += 2)
      for(int offset = -length - 1; offset + length <= 4; offset+=2 )
        V1.push_back(new _CLIMATE(1, pos, length, offset, 1, 100));

  for(int pos = 6; pos < 13; pos++)
      for(int offset = -4; offset < 2; offset += 2 )
        V1.push_back(new _CLIMATE(1, pos, 1, offset, 1, 10));

  for(int pos = 0; pos < 6; pos++)
    for(int length = 2; length < 8; length *= 2)
      for(int offset = 0; offset + length < 8; offset += length)
        V2.push_back(new _CLIMATE(1, pos, length, offset, 50));

*/

/*

   // mean variable in column 'pos' (0 to 5) in DroughtNOAA from plantDate + offset to plantDate + offset + length
   // manage to cover period before and during soy growth
   // Not all possible combination to reduce complexity
  vector<Extractor*> V2;
  for(int pos = 0; pos < 6; pos++)
    for(int length = 1; length < 12; length += 2)
      for(int offset = -length - 1; offset + length <= 6; offset++ )
        V2.push_back(new _CLIMATE(1, pos, length, offset, 1));
   // mean variable in columnn 'pos' (6 to 12) in DroughtNOAA for plantDate + offset date
   // As these variables are already cumulative vars, no need to make means.
   // Not all possible combination to reduce complexity

    for(int pos = 6; pos < 13; pos++)
    for(int offset = -6; offset < 6; offset += pos - 5 )
      V2.push_back(new _CLIMATE(1, pos, 1, offset, 1));
*/

/*   // mean variable in column 'pos' (0 to 5) in DroughtNOAA from january + ofset to january + offset + length of the plant Year
   // Not all possible combination to reduce complexity
  for(int pos = 0; pos < 6; pos++)
    for(int length = 2; length < 10; length *= 2)
      for(int offset = 0; offset + length <= 12; offset += length/2)
        V2.push_back(new _CLIMATE(1, pos, length, offset, 0));
*/
/*
   // mean variable in column 'pos' (0 to 4) in DroughtMonitor from plantDate + offset to plantDate + offset + length
   // manage to cover period before and during soy growth
   // Not all possible combination to reduce complexity
  vector<Extractor*> V4;
  for(int pos = 0; pos < 5; pos++)
    for(int length = 1; length <= 16; length *= 2)
      for(int offset = -length - 1; offset + length < 20; offset += length)
        V4.push_back(new _CLIMATE(0, pos, length, offset, 1));

   // Special combination of the 4 vars of DroughtMonitor = D0 + 2 * D1 + 3 * D2 + 4 * D3
   // of different length and offset.
    for(int length = 1; length <= 16; length *= 2)
      for(int offset = -length - 1; offset + length < 20; offset += length)
        V4.push_back(new _PAIR(
              new _PAIR(new _CLIMATE(0, 1, length, offset, 1), new _CLIMATE(0, 2, length, offset, 1), 1, 1, 1, 1),
              new _PAIR(new _CLIMATE(0, 3, length, offset, 1), new _CLIMATE(0, 4, length, offset, 1), 1, 1, 1, 1),
              1, 1, 1, 1));
*/
              

    cout << "#Extractor* EXTR[" << V1.size() << "] = {";
    cout.flush();
    for(int i= 0; i < V1.size(); i++) {
      cout << "new " << V1[i]->print();
    cout.flush();
      if(i == V1.size() - 1) cout << "};" << endl;
      else cout << ",";
      V1[i]->pos = i;
    cout.flush();
    }

/*
  for(int i = 0; i < V1.size(); i++) 
    for(int j = i; j < V1.size(); j++) 
      V2.push_back(new _PAIR(V1[i], V1[j], 1000, 1, 1, 1));
*/

  cerr << "V1 size" << V1.size() << endl;
  cerr << "V2 size" << V2.size() << endl;


  vector<Bucket*> Selection;
  Selection.push_back(new Bucket(new _EMPTY(), 1, 1.));

  YP.clear();
  YP.resize(TRAINKEY.size());

  for(int k = 0; k < Selection.size(); k++) {
    Selection[k]->init();
    for(int i = 0; i < TRAINKEY.size(); i++) 
      Selection[k]->train(TRAINKEY[i], YIELD[i] - YP[i]);

    Selection[k]->compute_pred();
    for(int i = 0; i < TRAINKEY.size(); i++) 
      YP[i] += Selection[k]->predict(TRAINKEY[i]);

    Selection[k]->clear();
  }

  int PARAM[NB_THREAD];
  for(int i = 0; i < NB_THREAD; i++) PARAM[i] = i;
  for(int i = 0; i < NB_THREAD; i++) pthread_create(&(threads[i]), NULL, thread_bufferize, (void*)(PARAM+i));
  for(int i = 0; i < NB_THREAD; i++) pthread_join(threads[i], NULL);

  double alpha = 0.2;
  for(int step = Selection.size(); step < 4000; step++) {

    for(int i = 0; i < Cand.size(); i++) {
      Cand[i]->clear();
      delete Cand[i];
    }
    Cand.clear();

    for(int i = 0; i < 512; i++) {
      int a,b;
      if(rand() % 4 == 0) a = 6 + rand() % 13;
      else a = rand()%6;
      if(rand() % 4 == 0) b = 6 + rand() % 13;
      else b = rand()%6;
      Cand.push_back(new Bucket(new _PAIR(V1[a], V1[b], 10 + rand()%2000, 1 + rand()%8, 1 + rand()%8, 1 + rand()%8), 5*step + rand()%50, 0.025 + alpha));
    }
    for(int i = 0; i < 128; i++) {
      int a;
      if(rand() % 4 == 0) a = 6 + rand() % 13;
      else a = rand()%6;

      int source = rand()%2;
      int pos;
      int l;
      if(source == 0) {
        pos = rand() % 15;
        l = 6;
      }
      else {
        pos = rand() % 6;
        l = 12;
      }
      int length = 1 + rand() % l;
      int offset = -length - 1 + rand() % l;
      int ratio = 5 + rand() % 200;
      Cand.push_back(new Bucket(new _PAIR(V1[a], new _CLIMATE(source, pos, length, offset, 1, ratio), 10 + rand()%2000, 1 + rand()%8, 1 + rand()%8, 1 + rand()%8), 5*step + rand()%50, 0.025 + alpha));
    }

    cerr << "step: " << step << endl;

    //    NB_THREAD = 1;
    for(int i = 0; i < NB_THREAD; i++) pthread_create(&(threads[i]), NULL, thread_train, (void*)(PARAM+i));
  for(int i = 0; i < NB_THREAD; i++) pthread_join(threads[i], NULL);
  cerr << "train: OK" << endl;

  MSE.resize(Cand.size());
  //MSE_VAL.resize(Cand.size());
  memset(&MSE[0], 0, MSE.size()*sizeof(double));
//  memset(&MSE_VAL[0], 0, MSE_VAL.size()*sizeof(double));
  for(int i = 0; i < NB_THREAD; i++) {
    PARAM[i] = i;
    pthread_create(&(threads[i]), NULL, thread_mse, (void*)(PARAM+i));
  }
  for(int i = 0; i < NB_THREAD; i++) pthread_join(threads[i], NULL);
  cerr << "rmse: OK" << endl;


  int best_i = 0;
  int nb = TRAINKEY.size();
  for(int i = 0; i < Cand.size(); i++) {
    if(MSE[i] < MSE[best_i]) best_i = i;
    cout << step << " " << i << " "<< sqrt(MSE[i]/nb) << /*" " << sqrt(MSE_VAL[i]/nb) <<*/ " " << Cand[i]->print() << endl;
  }

  //Selection.push_back(new Bucket(*Cand[best_i]));

  //Selection[Selection.size()-1]->compute_pred(); 
  double M = 0., M2 = 0.;
  for(int i = 0; i < TRAINKEY.size(); i++) {      
    YP[i] += Cand[best_i]->predict(TRAINKEY[i]);
    double err = (YIELD[i] - YP[i]);
    M += err*err;
    if(err*err > 25*25) err = 25;
      M2 += err*err;
    }
    cout << endl << step << " " << Cand[best_i]->print() << " " << sqrt(M/nb) << " " << sqrt(M2/nb) << " " << sqrt(MSE[best_i]/nb) << endl << endl;
    cout << "#" << Cand[best_i]->E->print() << "#" << Cand[best_i]->M << "#" << Cand[best_i]->alpha << endl;  

//    Selection[Selection.size()-1]->clear();
    alpha *= 0.99;
  }


}



