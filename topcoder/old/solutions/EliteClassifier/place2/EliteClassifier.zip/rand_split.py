#!/usr/bin/python
import sys
import string
import random

lines = sys.stdin.readlines()

col_num = len(lines[0].rstrip('\n').split(","))
row_num = len(lines) 

eid_num  = 0 
eid_info = [[0,0,0]]*10240  # (id, start, row)

for i in range(len(lines)):
	line = lines[i].rstrip('\n')
	cols = line.split(",")

	if (col_num != len(cols)):
		print "WRONG LINE", line
		sys.exit(0)	

	(eid, year, loc, check, y) = (cols[0], cols[1], cols[2], cols[9], cols[6])

	if (eid_num <= 0 or cols[0] != eid_info[eid_num-1][0]):
		eid_num += 1
		eid_info[eid_num-1] = [eid, i, 1]
	else:
		eid_info[eid_num-1][2] += 1

def rand_sample(eid_num, eid_info):
	kSelExprNum = 200 
	kExprNumPerGroup = 50 
	
	for i in range(kSelExprNum):
		sel_expr = random.sample(range(eid_num), kExprNumPerGroup); 

		file = open("group_"+str(i)+".csv", "w");
		for expr in sel_expr:
			for line in range(eid_info[expr][1], eid_info[expr][1] + eid_info[expr][2]):
				print >> file, lines[line].rstrip('\n')
		file.close()

def rand_split(eid_num, eid_info):
	kRatio = 0.4
	file1 = open("train.csv", "w");
	file2 = open("validate.csv", "w");
	
	for i in range(eid_num):
		file = file1
		if (random.random() >= kRatio): file = file2

		for line in range(eid_info[i][1], eid_info[i][1] + eid_info[i][2]):
			print >> file, lines[line].rstrip('\n')

	file1.close()
	file2.close()	

rand_split(eid_num, eid_info)
#rand_sample(eid_num, eid_info)
