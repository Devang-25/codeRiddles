#!/usr/bin/python
import sys
import string
from math import *

# x => (y_sum, y_num, miss_num, y_avg, y_std)
def add_elem(table, x, y):
	if (x in table):
		if (y=="?"):
			table[x][2] += 1
		else:
			table[x][0] += y
			table[x][1] += 1
			table[x][4] += y*y
	else:
		if (y=="?"):
			table[x] = [0, 0, 1, 0, 0]
		else:
			table[x] = [y, 1, 0, 0, y*y]

def process_table(table):
	for x in table:
		table[x][3] = float(table[x][0])/(float(table[x][1]) + 0.001)
		table[x][4] = float(table[x][4])/(float(table[x][1]) + 0.001)
		table[x][4] = sqrt(table[x][4] - table[x][3]*table[x][3])
		if (table[x][1]==0):
			table[x][3] = "?"
			table[x][4] = "?"

def write_table(table, name):
	file = open(name, "w")
	for x in table:
		if (len(x)==1):
			print >> file, "%s %s %d %d"%(x[0], table[x][3], table[x][1], table[x][2])
		elif (len(x)==2):
			print >> file, "%s %s %s %d %d"%(x[0], x[1], table[x][3], table[x][1], table[x][2])
		elif (len(x)==3):
			print >> file, "%s %s %s %s %s %d %d"%(x[0], x[1], x[2], table[x][3], table[x][4], table[x][1], table[x][2])
	file.close()

lines = sys.stdin.readlines()

col_num    = len(lines[0].rstrip('\n').split(","))
row_num    = len(lines) 

year_check     = {}
year_check_loc = {}

for i in range(len(lines)):
	line = lines[i].rstrip('\n')
	cols = line.split(",")

	if (col_num != len(cols)):
		print "WRONG LINE", line
		sys.exit(0)	

	(year, loc, check, y) = (string.atoi(cols[1]), string.atoi(cols[2]), string.atoi(cols[9]), cols[6])
	year -= 2000
	if (y!="NULL"): y=float(y)
	else: y='?'

	add_elem(year_check, (year, check), y)
	add_elem(year_check_loc, (year, check, loc), y)

process_table(year_check)
process_table(year_check_loc)

write_table(year_check, "year_check")
write_table(year_check_loc, "year_check_loc")

file = open("code", "w")
for (year, check, loc) in year_check_loc:
	if (check==0):
		v = year_check_loc[(year, check, loc)]
		print >> file, "\tyear_loc_avg[%d][%d]=%.3f; year_loc_sum[%d][%d]=%d;"%(year, loc, v[0], year, loc, v[1])

file.close()

