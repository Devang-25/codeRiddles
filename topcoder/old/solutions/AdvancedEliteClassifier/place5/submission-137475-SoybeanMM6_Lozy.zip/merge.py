f1 = open("sb1train.csv") # training data in match1
f2 = open("DataTraining.csv") # training data in match6
fo = open("train.csv", "w") # the final train data
hi = set()
data = []
for l in f2:
	tmp = l.split(",")
	hi.add(int(tmp[0]))
	data.append(l)
print len(hi)
h2 = set()
for l in f1:
	tmp = l.strip().split(",")
	if int(tmp[0]) in hi: continue
	h2.add(int(tmp[0]))
	data.append("%s,%s,%s,%s,%s-XX-XX,%s,%s,%s,%s,NULL,NULL,NULL,NULL,NULL,NULL,%s,%s\n" % 
		(tmp[0], tmp[2], tmp[3], tmp[5], tmp[1], tmp[4], tmp[6], tmp[7],
		tmp[8], tmp[9], tmp[10]))
print len(hi) + len(h2)
data = sorted(data)
for l in data:
	fo.write(l)
fo.close()